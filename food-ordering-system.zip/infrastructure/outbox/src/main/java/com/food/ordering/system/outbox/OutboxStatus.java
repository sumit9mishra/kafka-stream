package com.food.ordering.system.outbox;

public enum OutboxStatus {
    STARTED, COMPLETED, FAILED
}
